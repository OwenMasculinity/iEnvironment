package com.wsn.ienvironment;

import android.app.Activity;
import android.os.Bundle;

/**
 * author：张凌霄
 */
public class Historyweather extends Activity{
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.historyweather);

    }
}
