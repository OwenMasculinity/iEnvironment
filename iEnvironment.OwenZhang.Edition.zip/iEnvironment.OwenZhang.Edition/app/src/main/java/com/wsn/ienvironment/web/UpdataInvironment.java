package com.wsn.ienvironment.web;

/**
 * Created by asus on 2016/6/13.
 */
public class UpdataInvironment {
}
