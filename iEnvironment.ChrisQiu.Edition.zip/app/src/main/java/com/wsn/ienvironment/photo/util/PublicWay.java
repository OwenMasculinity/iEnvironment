package com.wsn.ienvironment.photo.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


import android.app.Activity;
import android.graphics.BitmapFactory;

/**
 * 存放所有的list在最后退出时一起关闭
 *
 * @author king
 * @QQ:595163260
 * @version 2014年10月18日  下午11:50:49
 */
public class PublicWay {
	public static List<Activity> activityList = new ArrayList<Activity>();
	
	public static int num = 9;
	
}
